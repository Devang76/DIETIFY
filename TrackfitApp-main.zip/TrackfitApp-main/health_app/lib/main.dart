import 'package:flutter/material.dart';
import 'package:health_app/Login&Signup/Login.dart';
import 'package:health_app/Login&Signup/LoginSignup.dart';
import 'package:health_app/Navbar.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: LoginSignupPage()
    );
  }
}
